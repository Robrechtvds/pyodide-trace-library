x = 0
for _ in range(3):
    x += 1